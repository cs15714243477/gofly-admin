export default {
	video: {
		errorMessageCopy: '复制错误信息',
		loadError: '视频加载失败！',
		uploadError: '上传视频失败！',
		uploadLimitError: '上传视频大小限制为 $size',
		download: '下载',
		preview: '预览',
		loading: '加载中...',
		transcoding: '转码中...',
	},
};
