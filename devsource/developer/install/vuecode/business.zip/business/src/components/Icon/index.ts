import IconPicker from './src/IconPicker.vue';
import Icon from './src/Icon.vue';

export { Icon, IconPicker };
export default Icon;