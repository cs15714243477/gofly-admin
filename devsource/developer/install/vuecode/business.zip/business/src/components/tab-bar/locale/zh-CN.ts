export default {
  'tabbar.cleseCurrent': '关闭当前',
  'tabbar.closeOther': '关闭其他',
  'tabbar.closeAll': '关闭全部',
  'tabbar.reloading': '重新加载',
  'tabbar.closeCurrent': '关闭当前标签页',
  'tabbar.closeLeft': '关闭左侧标签页',
  'tabbar.closeRight': '关闭右侧标签页',
  'tabbar.closeOtherTabs': '关闭其它标签页',
  'tabbar.closeAllTabs': '关闭全部标签页',
};
