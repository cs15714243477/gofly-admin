import en from './en-US';
import cn from './zh-CN';

export default {
	'en-US': en,
	'zh-CN': cn,
};
