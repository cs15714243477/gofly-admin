export default {
  'messageBox.switchRoles': '切换角色',
  'messageBox.userCenter': '用户管理',
  'messageBox.userSettings': '用户设置',
  'messageBox.logout': '登出登录',
};
