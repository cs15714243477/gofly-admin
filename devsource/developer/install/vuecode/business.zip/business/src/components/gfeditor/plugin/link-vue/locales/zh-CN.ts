export default {
	link: {
		text: '文本',
		link: '链接',
		juptType: '打开方式',
		text_placeholder: '描述文本',
		link_placeholder: '链接地址',
		link_open: '打开链接',
		link_edit: '编辑链接',
		link_remove: '移除链接',
		ok_button: '确定',
	},
};
