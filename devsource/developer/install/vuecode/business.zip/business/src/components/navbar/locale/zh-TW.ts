export default {
  'messageBox.switchRoles': '切換角色',
  'messageBox.userCenter': '用户管理',
  'messageBox.userSettings': '用户設置',
  'messageBox.logout': '登齣登録',
};
