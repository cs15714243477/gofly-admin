export default {
  'messageBox.switchRoles': 'Switch Roles',
  'messageBox.userCenter': 'User Management',
  'messageBox.userSettings': 'User Settings',
  'messageBox.logout': 'Logout',
};
