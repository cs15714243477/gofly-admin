export default {
	file: {
		errorMessageCopy: '复制错误信息',
		loadError: '文件加载失败！',
		uploadError: '上传文件失败！',
		uploadLimitError: '上传文件大小限制为 $size',
		download: '下载',
		preview: '预览',
	},
};
