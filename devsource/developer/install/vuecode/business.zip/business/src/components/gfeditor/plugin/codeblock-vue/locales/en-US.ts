export default {
	codeblock: {
		autoWrap: 'Auto Wrap',
	},
};
