export default {
  'business.rootname': '业务端管理',
  'business.bizuser.title': '账号管理',
};
