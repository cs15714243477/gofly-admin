export default {
  'menu.system.rule': '菜单管理',
 
};
