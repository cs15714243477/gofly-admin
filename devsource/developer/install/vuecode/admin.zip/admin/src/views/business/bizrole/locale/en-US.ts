export default {
  'business.role': 'Business role',
};
