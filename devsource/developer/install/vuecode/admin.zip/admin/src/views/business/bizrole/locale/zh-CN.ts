export default {
  'business.role': '业务角色',
  // columns

};
