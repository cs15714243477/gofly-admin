import{D as r,E as a}from"./umo-editor.70e1dfdc.js";const s=(n,o)=>r.lang.round(a.parse(n)[o]),e=s;export{e as c};
