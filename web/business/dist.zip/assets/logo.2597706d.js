const s="/webbusiness/logo.png";export{s as _};
