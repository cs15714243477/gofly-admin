import{D as r,E as a}from"./umo-editor.17280bf0.js";const s=(n,o)=>r.lang.round(a.parse(n)[o]),e=s;export{e as c};
