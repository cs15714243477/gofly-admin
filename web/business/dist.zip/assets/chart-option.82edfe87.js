import{c as t}from"./arco.92249096.js";import{u as n}from"./index.05c70217.js";function s(r){const o=n(),e=t(()=>o.theme==="dark");return{chartOption:t(()=>r(e.value))}}export{s as u};
