import{c as t}from"./arco.1c9d7883.js";import{u as n}from"./index.7609fcc7.js";function s(r){const o=n(),e=t(()=>o.theme==="dark");return{chartOption:t(()=>r(e.value))}}export{s as u};
